﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

namespace Dadi
{
    /// <summary>
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        Random r;
        int sorteggio1, sorteggio2;

        public MainWindow()
        {
            InitializeComponent();

            r = new Random();

            SorteggioDado1();
            SorteggioDado2();

        }

        private async void SorteggioDado1()
        {
            await Task.Run(() =>
            {

                while (true)
                {
                    sorteggio1 = r.Next(1, 7);
                    this.Dispatcher.BeginInvoke(new Action(() => {
                        lblOutput1.Content = sorteggio1;
                    }));
                    Thread.Sleep(200);
                }

            });
        }
        
        private void btnSorteggia_Click(object sender, RoutedEventArgs e)
        {
            int somma = sorteggio1 + sorteggio2;

            BitmapImage image1 = new BitmapImage(new Uri(sorteggio1.ToString() + ".png", UriKind.Relative));
            img1.Source = image1;

            BitmapImage image2 = new BitmapImage(new Uri(sorteggio2.ToString() + ".png", UriKind.Relative));
            img2.Source = image2;

        }

        private async void SorteggioDado2()
        {
            await Task.Run(() =>
            {

                while (true)
                {
                    sorteggio2 = r.Next(1, 7);
                    this.Dispatcher.BeginInvoke(new Action(() => {
                        lblOutput2.Content = sorteggio2;
                    }));
                    Thread.Sleep(200);
                }

            });
        }

        
    }
}
